import React, { Component } from "react"; //imrse
const Contact = () => {
  //sfc
  return <h1>Contact</h1>;
};

export default Contact;
