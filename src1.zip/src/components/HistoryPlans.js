// HistoryPlans.js — compact, polished “History/Shared” with share flow
import React, { useCallback, useEffect, useMemo, useState } from "react";
import "./HistoryPlans.css";

/* --------- Config --------- */
const API_BASE = "http://localhost:8012/www/tripmasterv01/public";
const getUID = () => localStorage.getItem("uid") || "";

/* --------- Small utils --------- */
const fmt = (d)=> d? new Date(d).toLocaleString(): "Dates not specified";
const safeParse = (v,f=[])=>{ try{ if(Array.isArray(v)) return v; if(typeof v==="string") return JSON.parse(v||"[]"); return f;}catch{return f;}};
const toSrc = (rel)=> /^https?:\/\//i.test(rel||"")? rel : `${API_BASE}/${String(rel||"").replace(/^\//,"")}`;

/* --------- Stars --------- */
const Star=({on,onClick,onMouseEnter})=>(
  <button type="button" className={`hp-star ${on?"on":""}`} onClick={onClick} onMouseEnter={onMouseEnter} aria-label="rate">★</button>
);
const Stars=({value=5,onChange})=>{
  const [h,setH]=useState(0); const shown=h||value;
  return (<div className="hp-stars" onMouseLeave={()=>setH(0)}>
    {[1,2,3,4,5].map(n=><Star key={n} on={shown>=n} onClick={()=>onChange(n)} onMouseEnter={()=>setH(n)}/>)}
  </div>);
};

/* --------- Component --------- */
export default function HistoryPlans({ uid = getUID() }){
  const [tab,setTab]=useState("history");     // history | shared
  const [rawHistory,setRawHistory]=useState([]), [rawShared,setRawShared]=useState([]);
  const [open,setOpen]=useState({});          // share editor visibility per trip
  const [rate,setRate]=useState({}), [note,setNote]=useState({}), [files,setFiles]=useState({});
  const [busy,setBusy]=useState({}), [msg,setMsg]=useState({});
  const [details,setDetails]=useState(null);  // modal
  const [lightbox,setLightbox]=useState({open:false,index:0});

  /* ---- Load my finished trips (history) ---- */
  const loadHistory=useCallback(async()=>{
    if(!uid) return;
    try{
      const fd=new FormData(); fd.append("uid",uid);
      const res=await fetch(`${API_BASE}/loadHistory.php`,{method:"POST",body:fd});
      const data=await res.json().catch(()=>[]);
      const arr = Array.isArray(data) ? data.map(x=>({
        ...x,
        places: safeParse(x.places),
        eventCalender: safeParse(x.eventCalender),
        images: safeParse(x.images)
      })) : [];
      setRawHistory(arr);
    }catch{ setRawHistory([]); }
  },[uid]);

  /* ---- Load my shared stories (for Shared/Archived tab) ---- */
  const loadShared=useCallback(async()=>{
    try{
      const res=await fetch(`${API_BASE}/get_stories.php?q=&ratingEq=all&sort=new`,{cache:"no-store"});
      const data=await res.json().catch(()=>({ok:false,items:[]}));
      const mine=data?.ok? data.items.filter(s=>String(s.user_id)===String(uid)) : [];
      setRawShared(mine.map(s=>({
        id: s.trip_id ?? s.id,
        titlePlan: s.title,
        eventCalender: safeParse(s.eventCalender),
        created_at: s.created_at,
        rating: Number(s.rating||0),
        notes: s.notes||"",
        images: Array.isArray(s.images)?s.images:safeParse(s.images),
        startDate: s.start_date,
        endDate: s.end_date
      })));
    }catch{ setRawShared([]); }
  },[uid]);

  useEffect(()=>{ loadHistory(); loadShared(); },[loadHistory,loadShared]);

  /* ---- Derived lists ---- */
  const sharedIds=useMemo(()=> new Set(rawShared.map(t=>Number(t.id))),[rawShared]);
  const historyList=useMemo(()=> rawHistory.filter(t=>!sharedIds.has(Number(t.id))),[rawHistory,sharedIds]);
  const list = tab==="history"? historyList : rawShared;

  /* ---- File pick/remove ---- */
  const onPickFiles=(tripId, fileList)=>{
    const inc=Array.from(fileList||[]);
    setFiles(prev=>{
      const merged=[...(prev[tripId]||[]),...inc]; const seen=new Set(); const out=[];
      for(const f of merged){ const k=[f.name,f.size,f.lastModified].join("|"); if(!seen.has(k)){seen.add(k); out.push(f);} }
      return {...prev,[tripId]:out.slice(0,12)};
    });
  };
  const removePicked=(tripId,idx)=> setFiles(prev=>{ const a=[...(prev[tripId]||[])]; a.splice(idx,1); return {...prev,[tripId]:a}; });

  /* ---- Share submit ---- */
  const submitShare=useCallback(async(trip)=>{
    const id=Number(trip.id), r=rate[id]||5, n=(note[id]||"").trim();
    if(!n){ setMsg(m=>({...m,[id]:"Please write a short note."})); return; }
    setBusy(b=>({...b,[id]:true}));
    try{
      const fd=new FormData();
      fd.append("user_id",uid); fd.append("trip_id",String(id));
      fd.append("title",trip.titlePlan||"My Trip");
      fd.append("rating",String(r)); fd.append("notes",n);
      fd.append("country",trip.titlePlan||"");
      (files[id]||[]).forEach(f=>fd.append("photos[]",f));
      const res=await fetch(`${API_BASE}/insert_story.php`,{method:"POST",body:fd});
      const data=await res.json().catch(()=>null);
      if(res.ok&&data?.ok){
        setMsg(m=>({...m,[id]:"Shared successfully ✅"}));
        setOpen(o=>({...o,[id]:false}));
        setNote(nm=>({...nm,[id]:""})); setFiles(fs=>({...fs,[id]:[]}));
        await loadShared(); setTab("shared");           // انتقل لتبويب Shared بعد المشاركة
        // اختيارياً: شيلها من history مباشرة
        setRawHistory(h=>h.filter(t=>Number(t.id)!==id));
      }else{ setMsg(m=>({...m,[id]:data?.error||"Server error"})); }
    }catch(e){ setMsg(m=>({...m,[id]:e.message||"Network error"})); }
    finally{ setBusy(b=>({...b,[id]:false})); }
  },[uid,rate,note,files,loadShared]);

  return (
    <div className="hp2-container">
      <h2 className="hp2-title">My Trips</h2>

      <div className="hp2-tabs">
        <button className={`hp2-tab ${tab==="history"?"is-active":""}`} onClick={()=>setTab("history")}>History</button>
        <button className={`hp2-tab ${tab==="shared"?"is-active":""}`}  onClick={()=>setTab("shared")}>Shared/Archived</button>
      </div>

      {list.length===0 ? (
        <p className="hp2-empty">{tab==="history"?"No trips left to share.":"No shared trips yet."}</p>
      ) : (
        <div className="hp2-grid">
          {list.map(trip=>{
            const id=Number(trip.id), isOpen=!!open[id], preview=(trip.eventCalender||[]).slice(0,3);
            return (
              <article key={id} className="hp2-card">
                <div className="hp2-card-body">
                  <header className="hp2-card-head">
                    <h3 className="hp2-card-title" title={trip.titlePlan}>{trip.titlePlan||"My Trip"}</h3>
                    <span className="hp2-badge">{tab==="shared" ? `Shared at: ${fmt(trip.created_at)}` : "Ended"}</span>
                  </header>

                  {Array.isArray(trip.images)&&trip.images.length>0 ? (
                    <div className="hp2-thumbs" role="button" onClick={()=>setDetails(trip)}>
                      {trip.images.slice(0,4).map((src,i)=>(<div className="hp2-thumb" key={i}><img src={toSrc(src)} alt=""/></div>))}
                      {trip.images.length>4 && <div className="hp2-more">+{trip.images.length-4}</div>}
                    </div>
                  ) : <div className="hp2-noimg" onClick={()=>setDetails(trip)}>No photos</div>}

                  <div className="hp2-section">
                    <div className="hp2-section-title">Visited Places</div>
                    <ul className="hp2-visited">
                      {preview.length? preview.map((p,i)=>(
                        <li key={i}><strong>{p?.title||"Untitled"}</strong> <span className="hp2-type">{p?.type?`(${p.type})`:""}</span></li>
                      )) : <li className="hp2-muted">No visited places recorded.</li>}
                    </ul>
                  </div>
                </div>

                {/* Footer actions */}
                <div className="hp2-actions">
                  <button className="hp2-btn" onClick={()=>setDetails(trip)}>More details</button>
                  {tab==="history" ? (!isOpen
                    ? <button className="hp2-btn hp2-btn-primary" onClick={()=>setOpen(o=>({...o,[id]:true}))}>Share</button>
                    : <button className="hp2-btn" onClick={()=>setOpen(o=>({...o,[id]:false}))}>Cancel</button>)
                    : <button className="hp2-btn hp2-btn-success" disabled>Shared</button>}
                </div>

                {/* Inline share editor */}
                {tab==="history" && isOpen && (
                  <div className="hp2-share">
                    <label className="hp2-lbl">Rate your trip</label>
                    <Stars value={rate[id]||5} onChange={(v)=>setRate(r=>({...r,[id]:v}))}/>

                    <label className="hp2-lbl">Notes</label>
                    <textarea className="hp2-input hp2-textarea" value={note[id]||""}
                              onChange={e=>setNote(n=>({...n,[id]:e.target.value}))}
                              placeholder="What stood out? Any tips for others?"/>

                    <label className="hp2-lbl">Photos (optional)</label>
                    <input className="hp2-input" type="file" accept="image/*" multiple
                           onChange={e=>{onPickFiles(id,e.target.files); e.target.value="";}}/>
                    {!!files[id]?.length && (
                      <div className="hp2-previews">
                        {files[id].map((f,i)=>(
                          <div key={i} className="hp2-preview">
                            <img src={URL.createObjectURL(f)} alt="" className="hp2-preview-img"/>
                            <button className="hp2-preview-x" onClick={()=>removePicked(id,i)}>×</button>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="hp2-share-actions">
                      <button className="hp2-btn hp2-btn-primary" onClick={()=>submitShare(trip)} disabled={!!busy[id]}>
                        {busy[id]?"Saving...":"Done"}
                      </button>
                      <button className="hp2-btn" onClick={()=>setOpen(o=>({...o,[id]:false}))}>Cancel</button>
                    </div>
                    {msg[id] && <div className="hp2-msg">{msg[id]}</div>}
                  </div>
                )}
              </article>
            );
          })}
        </div>
      )}

      {/* Details modal */}
      {details && (
        <div className="hp2-layer" onClick={()=>setDetails(null)}>
          <div className="hp2-dialog" onClick={(e)=>e.stopPropagation()}>
            <button className="hp2-close" onClick={()=>setDetails(null)}>×</button>
            <h3 className="hp2-dialog-title">{details.titlePlan || "Trip details"}</h3>

            {Array.isArray(details.images)&&details.images.length>0 && (
              <>
                <div className="hp2-gallery">
                  {details.images.map((src,i)=>(
                    <img key={i} src={toSrc(src)} alt="" onClick={()=>setLightbox({open:true,index:i})}/>
                  ))}
                </div>
                {lightbox.open && (
                  <div className="hp2-lightbox" onClick={()=>setLightbox({open:false,index:0})}>
                    <button className="hp2-lbx-close" onClick={(e)=>{e.stopPropagation();setLightbox({open:false,index:0});}}>×</button>
                    <button className="hp2-lbx-nav prev" onClick={(e)=>{e.stopPropagation(); setLightbox(s=>({open:true,index:(s.index-1+details.images.length)%details.images.length}));}}>‹</button>
                    <img src={toSrc(details.images[lightbox.index])} alt="" onClick={(e)=>e.stopPropagation()}/>
                    <button className="hp2-lbx-nav next" onClick={(e)=>{e.stopPropagation(); setLightbox(s=>({open:true,index:(s.index+1)%details.images.length}));}}>›</button>
                  </div>
                )}
              </>
            )}

            <div className="hp2-itin">
              <div className="hp2-itin-title">Itinerary</div>
              <ul className="hp2-itin-list">
                {(details.eventCalender||[]).length ? (
                  details.eventCalender.map((ev,i)=>(
                    <li key={i} className="hp2-itin-row">
                      <div className="hp2-itin-name">{ev.title||"Untitled"}</div>
                      <div className="hp2-itin-type">{ev.type||"—"}</div>
                      <div className="hp2-itin-time">{ev.start}{ev.end?` → ${ev.end}`:""}</div>
                    </li>
                  ))
                ) : <li className="hp2-muted">No itinerary found.</li>}
              </ul>
            </div>

            <div className="hp2-dialog-actions">
              <button className="hp2-btn hp2-btn-primary" onClick={()=>setDetails(null)}>Close</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
