<?php
// ---------- CORS ----------
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
$allowed = ['http://localhost:3000','http://127.0.0.1:3000','http://localhost','http://localhost:8012'];
if ($origin && in_array($origin, $allowed, true)) {
  header("Access-Control-Allow-Origin: $origin");
  header("Vary: Origin");
}
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Headers: Content-Type, Accept, Origin");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

// ---------- DB ----------
$DB_HOST = '127.0.0.1';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'tripmaster';   // نفس اسم الداتا بيز اللي بتشتغل عليها

$mysqli = @mysqli_connect($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if (!$mysqli) { http_response_code(500); echo json_encode(['ok'=>false,'error'=>'DB connect failed']); exit; }
mysqli_set_charset($mysqli, 'utf8mb4');

// ---------- helpers ----------
function jexit($arr){ header('Content-Type: application/json; charset=utf-8'); echo json_encode($arr, JSON_UNESCAPED_UNICODE); exit; }
function bad_request($msg){ http_response_code(400); jexit(['ok'=>false,'error'=>$msg]); }

// رفع عدة صور
function upload_many($key='photos'){
  $paths = [];
  if (!isset($_FILES[$key])) return $paths;
  $dir = __DIR__.'/uploads';
  if (!is_dir($dir)) @mkdir($dir, 0777, true);
  foreach($_FILES[$key]['tmp_name'] as $i=>$tmp){
    if (!is_uploaded_file($tmp)) continue;
    $ext = pathinfo($_FILES[$key]['name'][$i]??'', PATHINFO_EXTENSION);
    $name = 'img_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).($ext?'.'.$ext:'');
    $dest = $dir.'/'.$name;
    if (move_uploaded_file($tmp, $dest)) $paths[] = 'uploads/'.$name;
  }
  return $paths;
}
