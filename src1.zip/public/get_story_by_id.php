<?php
require __DIR__.'/db.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) bad_request('missing id');

$stmt = mysqli_prepare($mysqli, "SELECT id,user_id,trip_id,title,notes,rating,country,images,start_date,end_date,eventCalender,duration_days,created_at FROM stories WHERE id=?");
mysqli_stmt_bind_param($stmt,'i',$id);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);
$item = mysqli_fetch_assoc($res);
if (!$item) jexit(['ok'=>false,'error'=>'not found']);

foreach(['images','eventCalender'] as $j){
  if (isset($item[$j])){
    $d = json_decode($item[$j], true);
    if (json_last_error()===JSON_ERROR_NONE) $item[$j]=$d;
  }
}
jexit(['ok'=>true,'item'=>$item]);
