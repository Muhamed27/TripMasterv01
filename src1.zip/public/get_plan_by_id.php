<?php
require __DIR__.'/db.php';
$id = (int)($_GET['id'] ?? 0);
if ($id<=0) bad_request('id required');
$r = $con->query("SELECT * FROM dashboard WHERE id=".$id)->fetch_assoc();
json_ok(['ok'=>!!$r, 'item'=>$r]);
