<?php
header('Content-Type: application/json; charset=utf-8');

/**
 * loadDb() — Load DB config (db.php or config.php) and expose a mysqli|PDO handle.
 * Returns: ['kind' => 'mysqli'|'pdo', 'dbh' => mysqli|PDO]
 */
function loadDb(): array {
  $inc = false;
  foreach ([__DIR__.'/../db.php', __DIR__.'/db.php', __DIR__.'/../config.php', __DIR__.'/config.php'] as $p) {
    if (file_exists($p)) { require_once $p; $inc = true; break; }
  }
  if (!$inc) throw new RuntimeException('DB config not found');

  // Normalize handle
  if (isset($mysqli) && $mysqli instanceof mysqli) return ['kind'=>'mysqli','dbh'=>$mysqli];
  if (isset($con)    && $con    instanceof mysqli) return ['kind'=>'mysqli','dbh'=>$con];
  if (isset($pdo)    && $pdo    instanceof PDO)    return ['kind'=>'pdo','dbh'=>$pdo];

  throw new RuntimeException('No DB connection');
}

/**
 * hasColumn() — Check if a column exists in `dashboard`.
 */
function hasColumn($dbh, string $kind, string $col): bool {
  $sql = "SHOW COLUMNS FROM dashboard LIKE '$col'";
  $q   = ($kind==='mysqli') ? $dbh->query($sql) : $dbh->query($sql);
  if (!$q) return false;
  return ($kind==='mysqli') ? $q->num_rows > 0 : $q->rowCount() > 0;
}

/**
 * fetchAllAssoc() — Fetch all rows from a prepared statement as assoc arrays.
 */
function fetchAllAssoc($stmt, string $kind): array {
  if ($kind==='mysqli') {
    $res = $stmt->get_result(); $rows=[];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
  }
  return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

try {
  // ---- Inputs (keep same names for compatibility) ----
  $userid = $_GET['userid'] ?? $_POST['userid'] ?? $_GET['uid'] ?? $_POST['uid'] ?? '';
  $status = $_GET['status']  ?? $_POST['status']  ?? 'active'; // active|shared|any

  // ---- DB ----
  ['kind'=>$kind,'dbh'=>$dbh] = loadDb();

  // ---- Detect columns ----
  $hasStatus = hasColumn($dbh,$kind,'status');
  $userCol   = 'userid';
  foreach (['userid','user_id','uid'] as $c) { if (hasColumn($dbh,$kind,$c)) { $userCol=$c; break; } }

  // ---- Build SELECT & WHERE ----
  $select = "id, titlePlan, smartDailyPlans, eventCalender, places".($hasStatus ? ", status" : "");
  $where  = []; $bind = []; $types = "";

  if ($hasStatus) {
    if ($status==='shared')    $where[] = "status='shared'";
    elseif ($status==='active') $where[] = "(status='active' OR status IS NULL OR status='')";
    // status=any => no filter
  }
  if ($userid!=='') { $where[] = "$userCol = ?"; $bind[] = $userid; $types .= "s"; }

  $sql = "SELECT $select FROM dashboard ".($where?("WHERE ".implode(" AND ",$where)):"")." ORDER BY id DESC";

  // ---- Execute ----
  $stmt = $dbh->prepare($sql);
  if (!$stmt) throw new RuntimeException('prepare failed');
  if ($kind==='mysqli') {
    if ($types!=='') { $stmt->bind_param($types, ...$bind); }
    if (!$stmt->execute()) throw new RuntimeException('execute failed');
  } else {
    $stmt->execute($bind);
  }
  $rows = fetchAllAssoc($stmt,$kind);
  if ($kind==='mysqli') $stmt->close();

  // ---- Fallback: try without user filter if empty but userid provided (keeps old data visible) ----
  if ($userid!=='' && count($rows)===0) {
    $where2 = [];
    if ($hasStatus) {
      if ($status==='shared')     $where2[] = "status='shared'";
      elseif ($status==='active') $where2[] = "(status='active' OR status IS NULL OR status='')";
    }
    $sql2 = "SELECT $select FROM dashboard ".($where2?("WHERE ".implode(" AND ",$where2)):"")." ORDER BY id DESC";
    $stmt2 = $dbh->prepare($sql2);
    ($kind==='mysqli') ? $stmt2->execute() : $stmt2->execute();
    $rows  = fetchAllAssoc($stmt2,$kind);
    if ($kind==='mysqli') $stmt2->close();
  }

  // ---- Map output to expected shape (flatten events / decode places) ----
  $out = [];
  foreach ($rows as $row) {
    $events = json_decode($row["eventCalender"] ?? "[]", true);
    if (!is_array($events)) $events = [];
    if (isset($events["eventCalender"]) && is_array($events["eventCalender"])) {
      $events = $events["eventCalender"]; // normalize nested shape
    }
    $places = json_decode($row["places"] ?? "[]", true);
    if (!is_array($places)) $places = [];

    $flatEvents = array_map(function($e){
      return [
        "event_id" => $e["id"]    ?? null,
        "title"    => $e["title"] ?? "",
        "type"     => $e["type"]  ?? "",
        "start"    => $e["start"] ?? null,
        "end"      => $e["end"]   ?? null
      ];
    }, $events);

    $out[] = [
      "dashboard_id" => (int)$row["id"],
      "id"           => (int)$row["id"],
      "titlePlan"    => $row["titlePlan"] ?? null,
      "events"       => $flatEvents,
      "eventCalender"=> $events,
      "places"       => $places,
      "status"       => $row["status"] ?? ($hasStatus ? null : "active"),
    ];
  }

  echo json_encode($out, JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'error'=>'DB query error']); // keep same error shape
}
