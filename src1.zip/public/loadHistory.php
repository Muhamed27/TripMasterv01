<?php
require_once __DIR__ . '/../config.php';
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn->set_charset('utf8mb4');

$uid = $_POST['uid'] ?? $_GET['uid'] ?? '';
if ($uid === '') { echo json_encode([]); exit; }

$stmt = $conn->prepare("
  SELECT id, userid, titlePlan, startDate, endDate, eventCalender, images
  FROM history
  WHERE userid = ?
  ORDER BY id DESC
");
$stmt->bind_param('s', $uid);
$stmt->execute();
$res = $stmt->get_result();

$out = [];
while ($r = $res->fetch_assoc()) {
  // رجّع JSON كسلاسل نصية لأن الواجهة بتعمل JSON.parse
  $images = $r['images'];
  if ($images === null || $images === '') $images = '[]';
  if (@json_decode($images) === null) { $images = '[]'; }

  $event = $r['eventCalender'];
  if ($event === null || $event === '') $event = '[]';
  if (@json_decode($event) === null) { $event = '[]'; }

  $out[] = [
    'id'            => (int)$r['id'],
    'userid'        => $r['userid'],
    'titlePlan'     => $r['titlePlan'],
    'startDate'     => $r['startDate'],
    'endDate'       => $r['endDate'],
    // لاحظ المفتاح بالحروف الصغيرة لأنه هكذا متوقع بالفرونت
    'eventcalender' => $event,
    'images'        => $images
  ];
}
echo json_encode($out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
