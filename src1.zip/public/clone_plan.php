<?php
require __DIR__.'/db.php';

$story_id  = isset($_POST['story_id']) ? (int)$_POST['story_id'] : null;
$src_trip  = isset($_POST['source_trip_id']) ? (int)$_POST['source_trip_id'] : null;
$title     = trim($_POST['title'] ?? 'My Trip');
$user_id   = trim($_POST['user_id'] ?? '');
$new_start = $_POST['new_start_date'] ?? null;
$dur_in    = (int)($_POST['duration_days'] ?? 0);

if ($user_id==='' || !$new_start) bad_request('user_id and new_start_date required');

$start = new DateTime($new_start);

$ev = null; $places='[]'; $startloc='{}'; $auto_days = 1;

if ($src_trip) {
  $q=$con->prepare("SELECT eventCalender, places, startloc, startDate, endDate FROM dashboard WHERE id=? LIMIT 1");
  $q->bind_param('i',$src_trip); $q->execute(); $src=$q->get_result()->fetch_assoc(); $q->close();
  if ($src) {
    $ev = $src['eventCalender']; $places = $src['places'] ?: '[]'; $startloc = $src['startloc'] ?: '{}';
    if ($src['startDate'] && $src['endDate']) {
      $auto_days = max(1, (int)round((strtotime($src['endDate'])-strtotime($src['startDate']))/86400)+1);
    }
  }
} elseif ($story_id) {
  $q=$con->prepare("SELECT eventCalender, start_date, end_date FROM stories WHERE id=? LIMIT 1");
  $q->bind_param('i',$story_id); $q->execute(); $src=$q->get_result()->fetch_assoc(); $q->close();
  if ($src) {
    $ev = $src['eventCalender'];
    if ($src['start_date'] && $src['end_date']) {
      $auto_days = max(1, (int)round((strtotime($src['end_date'])-strtotime($src['start_date']))/86400)+1);
    }
  }
}

if (!$ev) $ev = '[]';  // <<< مهم: حتى لو القصة بلا itinerary

$days = max(1, $dur_in ?: $auto_days);
$end   = clone $start; $end->modify(sprintf('+%d days', $days-1));
$startDate = $start->format('Y-m-d');
$endDate   = $end->format('Y-m-d');

$sql = "INSERT INTO dashboard (userid, smartDailyPlans, eventCalender, dailyHours, places, startloc, startDate, endDate, isActive, titlePlan, status)
        VALUES (?,?,?,?,?,?,?,?,?,?, 'active')";
$stmt = $con->prepare($sql);
$smart = '[]';
$dailyHours = '[]'; // يضمن ظهور الـ Grid
$isActive = 1;
$stmt->bind_param('ssssssssis', $user_id, $smart, $ev, $dailyHours, $places, $startloc, $startDate, $endDate, $isActive, $title);
if(!$stmt->execute()) bad_request('Clone failed');
$new_id = $stmt->insert_id;
$stmt->close();

json_ok(['ok'=>true,'new_plan_id'=>$new_id,'days'=>$days,'startDate'=>$startDate,'endDate'=>$endDate]);
