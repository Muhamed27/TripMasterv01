<?php
require __DIR__.'/db.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') bad_request('method');

$user_id = trim($_POST['user_id'] ?? '');
$trip_id = (int)($_POST['trip_id'] ?? 0);
$title   = trim($_POST['title'] ?? 'My Trip');
$rating  = (int)($_POST['rating'] ?? 0);
$notes   = trim($_POST['notes'] ?? '');
$country = trim($_POST['country'] ?? '');
if ($user_id==='') bad_request('user_id required');

// ارفع الصور (اختياري)
$imgs = upload_many('photos');
$imagesJson = json_encode($imgs, JSON_UNESCAPED_UNICODE);

// احفظ القصة
$stmt = mysqli_prepare($mysqli, "INSERT INTO stories (user_id,trip_id,title,notes,rating,country,images,created_at) VALUES (?,?,?,?,?,?,?,NOW())");
mysqli_stmt_bind_param($stmt,'sississ',$user_id,$trip_id,$title,$notes,$rating,$country,$imagesJson);
$ok = mysqli_stmt_execute($stmt);
if(!$ok) jexit(['ok'=>false,'error'=>mysqli_error($mysqli)]);
$id = mysqli_insert_id($mysqli);

// (اختياري) انسخ التاريخ/الايتيـنري من جدول history لو موجود
if ($trip_id){
  $stmt2 = mysqli_prepare($mysqli, "SELECT startDate,endDate,eventCalender FROM history WHERE id=? AND user_id=?");
  mysqli_stmt_bind_param($stmt2,'is',$trip_id,$user_id);
  if (mysqli_stmt_execute($stmt2)){
    $r = mysqli_stmt_get_result($stmt2);
    if ($h = mysqli_fetch_assoc($r)){
      $upd = mysqli_prepare($mysqli, "UPDATE stories SET start_date=?, end_date=?, eventCalender=? WHERE id=?");
      $ec = $h['eventCalender'];
      mysqli_stmt_bind_param($upd,'sssi',$h['startDate'],$h['endDate'],$ec,$id);
      @mysqli_stmt_execute($upd);
    }
  }
}

jexit(['ok'=>true,'id'=>$id,'images'=>$imgs]);
