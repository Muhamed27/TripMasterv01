<?php
// get_plan_details.php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/db.php';

function db_one($sql, $params = []) {
  if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) {
    $st = $GLOBALS['pdo']->prepare($sql);
    $st->execute($params);
    return $st->fetch(PDO::FETCH_ASSOC) ?: null;
  }
  if (isset($GLOBALS['conn']) && $GLOBALS['conn'] instanceof mysqli) {
    if ($params) {
      $st = $GLOBALS['conn']->prepare($sql);
      if (!$st) throw new Exception($GLOBALS['conn']->error);
      $types = str_repeat('s', count($params));
      $st->bind_param($types, ...$params);
      $st->execute();
      $res = $st->get_result();
      return $res ? $res->fetch_assoc() : null;
    } else {
      $res = $GLOBALS['conn']->query($sql);
      return $res ? $res->fetch_assoc() : null;
    }
  }
  throw new Exception('No DB connection ($pdo or $conn)');
}

$id = (int)($_GET['id'] ?? $_POST['id'] ?? 0);
if (!$id) { echo json_encode(['ok'=>false,'error'=>'missing id']); exit; }

try {
  $row = db_one("SELECT id, titlePlan, startDate, endDate, eventCalender
                 FROM dashboard WHERE id = ? LIMIT 1", [$id]);
  if (!$row) { echo json_encode(['ok'=>false,'error'=>'plan not found']); exit; }

  $events = [];
  if (!empty($row['eventCalender'])) {
    $tmp = json_decode($row['eventCalender'], true);
    if (is_array($tmp)) $events = $tmp;
  }

  echo json_encode([
    'ok'=>true,
    'plan'=>[
      'id'=>$row['id'],
      'title'=>$row['titlePlan'],
      'startDate'=>$row['startDate'],
      'endDate'=>$row['endDate'],
    ],
    'events'=>$events
  ], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
