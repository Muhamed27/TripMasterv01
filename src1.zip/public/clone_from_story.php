<?php
// public/clone_from_story.php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

require_once __DIR__ . '/db.php';
if (!isset($con) || !$con) { echo json_encode(['ok'=>false,'error'=>'db']); exit; }

$storyId   = (int)($_POST['story_id'] ?? 0);
$newStart  = trim($_POST['new_start'] ?? '');   // YYYY-MM-DD
if($storyId<=0 || $newStart===''){ echo json_encode(['ok'=>false,'error'=>'missing_params']); exit; }

/* هل عمود المستخدم في dashboard اسمه userid أم user_id ؟ */
$colUser = 'userid';
$check = $con->query("SHOW COLUMNS FROM dashboard LIKE 'userid'");
if(!$check || $check->num_rows==0){ $colUser = 'user_id'; }

/* جلب بيانات القصة + dashboard الأصلي (إن وجد) */
$sql = "SELECT s.*, d.dailyHours AS d_daily, d.eventCalender AS d_ev, d.title AS d_title, d.$colUser AS d_user
        FROM stories s
        LEFT JOIN dashboard d ON d.id = s.trip_id
        WHERE s.id=?";
$stmt = $con->prepare($sql);
$stmt->bind_param('i',$storyId);
$stmt->execute();
$st = $stmt->get_result()->fetch_assoc();
$stmt->close();

if(!$st){ echo json_encode(['ok'=>false,'error'=>'story_not_found']); exit; }

$title = $st['title'] ?: ($st['d_title'] ?: 'Cloned Trip');
$user  = $st['user_id'] ?: $st['d_user'];

/* نجهّز الـ eventCalender و dailyHours */
$evSrc = $st['eventCalender'] ?: $st['d_ev'];
$daily = $st['d_daily'];

// نحسب طول الأيام
$len = 1;
$evArr = json_decode((string)$evSrc, true);
if(is_array($evArr) && count($evArr)>0) $len = count($evArr);
if($len===1 && !empty($st['start_date']) && !empty($st['end_date'])){
  $sd=strtotime($st['start_date']); $ed=strtotime($st['end_date']);
  if($sd && $ed && $ed>=$sd) $len = (int)floor(($ed-$sd)/86400)+1;
}

/* لو dailyHours غايب: بنصنع مصفوفة طولها len */
if(!json_decode((string)$daily,true)){
  $tmp=[]; for($i=0;$i<$len;$i++) $tmp[] = ['items'=>[],'notes'=>''];
  $daily = json_encode($tmp, JSON_UNESCAPED_UNICODE);
}

/* تواريخ الرحلة الجديدة */
$startDate = date('Y-m-d', strtotime($newStart));
$endDate   = date('Y-m-d', strtotime("$newStart +".($len-1)." day"));

$evJson = $evSrc ?: json_encode([], JSON_UNESCAPED_UNICODE);

/* إدراج نسخة جديدة في dashboard */
$ins = $con->prepare("
  INSERT INTO dashboard (title, $colUser, startDate, endDate, dailyHours, eventCalender, created_at)
  VALUES (?,?,?,?,?,?, NOW())
");
$ins->bind_param('ssssss', $title, $user, $startDate, $endDate, $daily, $evJson);

if(!$ins->execute()){
  echo json_encode(['ok'=>false,'error'=>$ins->error]); 
  $ins->close(); 
  exit;
}
$newTripId = $ins->insert_id;
$ins->close();

echo json_encode(['ok'=>true,'trip_id'=>$newTripId,'startDate'=>$startDate,'endDate'=>$endDate]);
