<?php
// insert_notice.php — Create a notice (bulletin) record
header("Content-Type: application/json; charset=utf-8");
require_once __DIR__ . "/config.php";

/**
 * readJson() — Safely read JSON body as associative array.
 */
function readJson(): array {
  $raw = file_get_contents("php://input");
  $data = json_decode($raw, true);
  return is_array($data) ? $data : [];
}

/**
 * validateRequired() — Ensure required keys exist and are non-empty.
 */
function validateRequired(array $data, array $keys): ?string {
  foreach ($keys as $k) {
    if (empty($data[$k])) return $k; // missing key name
  }
  return null;
}

try {
  $data = readJson();

  // Required fields (keep same names used by frontend)
  $missing = validateRequired($data, ["type","title","description"]);
  if ($missing) { echo json_encode(["ok"=>false,"error"=>"Missing field: $missing"]); exit; }

  // Optional fields trimmed
  $params = [
    ":user_id"    => isset($data["user_id"]) ? trim($data["user_id"]) : "",
    ":name"       => isset($data["name"]) ? trim($data["name"]) : "",
    ":contact"    => isset($data["contact"]) ? trim($data["contact"]) : "",
    ":type"       => trim($data["type"]),
    ":title"      => trim($data["title"]),
    ":description"=> trim($data["description"]),
    ":location"   => isset($data["location"]) ? trim($data["location"]) : "",
    ":trip_dates" => isset($data["trip_dates"]) ? trim($data["trip_dates"]) : "",
  ];

  // Insert (PDO expected from config.php as $pdo)
  $sql = "INSERT INTO notices
            (user_id, name, contact, type, title, description, location, trip_dates, created_at)
          VALUES
            (:user_id, :name, :contact, :type, :title, :description, :location, :trip_dates, NOW())";
  $stmt = $pdo->prepare($sql);
  $stmt->execute($params);

  echo json_encode(["ok"=>true, "id"=>$pdo->lastInsertId()]);
} catch (Throwable $e) {
  http_response_code(500);
  echo json_encode(["ok"=>false, "error"=>"Insert failed"]);
}
