<?php
// CORS
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($origin === 'http://localhost:3000' || $origin === 'http://127.0.0.1:3000') {
  header("Access-Control-Allow-Origin: $origin");
  header("Access-Control-Allow-Credentials: true");
  header("Vary: Origin");
}
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../db.php'; // عدّل المسار إذا لزم
if (!isset($con) || !$con) { echo json_encode(['ok'=>false,'error'=>'DB connection']); exit; }

$uid   = trim($_POST['uid'] ?? '');
$title = trim($_POST['title'] ?? 'Cloned Trip');
$notes = trim($_POST['notes'] ?? '');
$start = trim($_POST['start_date'] ?? '');
$end   = trim($_POST['end_date'] ?? '');

if ($uid === '' || $start === '' || $end === '') {
  echo json_encode(['ok'=>false,'error'=>'Missing fields']); exit;
}

// مثال: جدول trips (بدّل الأسماء حسب نظامك)
$sql = "INSERT INTO trips (uid, title, notes, start_date, end_date, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())";
$stmt = mysqli_prepare($con, $sql);
if (!$stmt) { echo json_encode(['ok'=>false,'error'=>'Prepare failed']); exit; }
mysqli_stmt_bind_param($stmt, "sssss", $uid, $title, $notes, $start, $end);
if (!mysqli_stmt_execute($stmt)) { echo json_encode(['ok'=>false,'error'=>'Execute failed']); exit; }

$tripId = mysqli_insert_id($con);
mysqli_stmt_close($stmt);

echo json_encode(['ok'=>true,'trip_id'=>$tripId]);
