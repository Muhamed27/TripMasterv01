<?php
require __DIR__.'/db.php';

$q = trim($_GET['q'] ?? '');
$ratingEq = $_GET['ratingEq'] ?? 'all';
$sort = $_GET['sort'] ?? 'new';

$sql = "SELECT id,user_id,trip_id,title,notes,rating,country,images,start_date,end_date,eventCalender,duration_days,created_at FROM stories";
$where=[]; $args=[]; $types='';

if ($q !== '') {
  $where[]="(title LIKE CONCAT('%',?,'%') OR notes LIKE CONCAT('%',?,'%') OR country LIKE CONCAT('%',?,'%'))";
  $args[]=$q; $args[]=$q; $args[]=$q; $types.='sss';
}
if ($ratingEq !== 'all' && is_numeric($ratingEq)) { $where[]="rating=?"; $args[]=(int)$ratingEq; $types.='i'; }
if ($where) $sql .= ' WHERE '.implode(' AND ',$where);
$sql .= ($sort === 'rating') ? ' ORDER BY rating DESC, created_at DESC' : ' ORDER BY created_at DESC';

$stmt = mysqli_prepare($mysqli, $sql);
if ($args) mysqli_stmt_bind_param($stmt, $types, ...$args);
mysqli_stmt_execute($stmt);
$res = mysqli_stmt_get_result($stmt);

$items=[];
while($row = mysqli_fetch_assoc($res)){
  foreach(['images','eventCalender'] as $j){
    if (isset($row[$j]) && $row[$j]!=='' && $row[$j]!==null){
      $d = json_decode($row[$j], true);
      if (json_last_error()===JSON_ERROR_NONE) $row[$j]=$d;
    }
  }
  $items[]=$row;
}
jexit(['ok'=>true,'items'=>$items]);
