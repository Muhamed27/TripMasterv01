<?php
// get_dashboard_plans.php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

require_once __DIR__ . '/db_connect.php'; // عدّل حسب مشروعك (يفتح اتصال $pdo أو mysqli)
$uid = $_GET['uid'] ?? $_POST['uid'] ?? '';

if (!$uid) {
  echo json_encode(['ok'=>false,'error'=>'missing uid']); exit;
}

try {
  // استخدم PDO أو mysqli. هنا مثال PDO:
  $sql = "SELECT id, titlePlan, startDate, endDate
          FROM dashboard
          WHERE userid = ?
          ORDER BY startDate DESC, id DESC";
  $stmt = $pdo->prepare($sql);
  $stmt->execute([$uid]);
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

  // احسب الأيام (لو عندك start/end)
  foreach ($rows as &$r) {
    $days = 0;
    if (!empty($r['startDate']) && !empty($r['endDate'])) {
      $sd = new DateTime($r['startDate']);
      $ed = new DateTime($r['endDate']);
      $diff = $sd->diff($ed)->days;
      $days = $diff + 1;
    }
    $r['days'] = $days;
  }

  echo json_encode(['ok'=>true, 'items'=>$rows], JSON_UNESCAPED_UNICODE);
} catch (Throwable $e) {
  echo json_encode(['ok'=>false,'error'=>$e->getMessage()]);
}
